/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ingenieria1202610;

import figuras.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.JPanel;

public class PanelDeDibujo extends JPanel {

    private ArrayList<Figura> figuras = new ArrayList<>();
    private Figura figuraActual;
    private Color colorActual = Color.BLACK;
    private String herramienta = "lapiz";
    private int grosorActual = 2;
    // ← NUEVO: imagen del canvas para el balde
    private BufferedImage imagen;

    public PanelDeDibujo() {
        setBackground(Color.WHITE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Point puntoInicial = e.getPoint();

              switch (herramienta) {
    case "borrador":
        figuraActual = new Borrador();
        figuras.add(figuraActual);
        break;

    case "linea":                              // ← herramienta línea separada
        figuraActual = new Linea(puntoInicial);
        figuraActual.setColor(colorActual);
        figuras.add(figuraActual);
        break;

    case "balde":
        BoteDePintura balde = new BoteDePintura(puntoInicial, imagen);
        balde.setColor(colorActual);
        balde.rellenar();
        figuras.add(balde);
        break;

    default: // "lapiz" — siempre DibujoLibre
        figuraActual = new DibujoLibre();
        figuraActual.setColor(colorActual);
        figuras.add(figuraActual);
        break;
}
                repaint();
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (herramienta.equals("balde")) return; // balde no arrastra
                if (figuraActual != null) {
                    figuraActual.actualizar(e.getPoint());
                    repaint();
                }
            }
        });
    }

    public void setColorActual(Color color) {
        this.colorActual = color;
        this.herramienta = "lapiz";
        
    }

    public void setHerramienta(String herramienta) {
        this.herramienta = herramienta;
    }

    @Override
    protected void paintComponent(Graphics g) {
        // ← NUEVO: crear la imagen si no existe o cambió el tamaño
        if (imagen == null || imagen.getWidth() != getWidth() || imagen.getHeight() != getHeight()) {
            BufferedImage nueva = new BufferedImage(
                    Math.max(1, getWidth()),
                    Math.max(1, getHeight()),
                    BufferedImage.TYPE_INT_ARGB);
            Graphics2D ng = nueva.createGraphics();
            ng.setColor(Color.WHITE);
            ng.fillRect(0, 0, nueva.getWidth(), nueva.getHeight());
            if (imagen != null) {
                ng.drawImage(imagen, 0, 0, null);
            }
            ng.dispose();
            imagen = nueva;
        }

        // dibujar todas las figuras en la imagen
        Graphics2D g2 = imagen.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, imagen.getWidth(), imagen.getHeight());
        for (Figura figura : figuras) {
            figura.dibujar(g2);
        }
        g2.dispose();

        // mostrar la imagen en pantalla
        g.drawImage(imagen, 0, 0, null);
    }
}