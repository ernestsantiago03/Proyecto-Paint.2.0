/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 *
 * @author josearielpereyra
 */
public class Linea extends Figura{
    private Point puntoInicial;
    private Point puntoFinal; 

    public Linea(Point puntoInicial) {
        this.puntoInicial = puntoInicial;
        this.puntoFinal = puntoInicial;
    }
    
    public Linea(Point puntoInicial, Point puntoFinal) {
        this.puntoInicial = puntoInicial;
        this.puntoFinal = puntoFinal;
    }

    public void actualizar(Point puntoActual) {
        this.puntoFinal = puntoActual;
    }

    public void dibujar(Graphics g) {
        g.setColor(color);
        g.drawLine(puntoInicial.x, puntoInicial.y, puntoFinal.x, puntoFinal.y);//dibuja la linea
//*************************************************************************************I************        
//************************************usado para ejemplo (remover)************************************
//        int x = Math.min(puntoInicial.x, puntoFinal.x);
//        int y = Math.min(puntoInicial.y, puntoFinal.y);
//        int anchura = Math.abs(puntoFinal.x - puntoInicial.x);
//        int altura = Math.abs(puntoFinal.y - puntoInicial.y);
//        g.drawRect(x, y, anchura, altura);//dibuja rectgulo
//        g.drawOval(x, y, anchura, altura);//dibuja Ovalo
//        
//        g.setColor(Color.red);
//        g.drawPolygon(new int[]{x, x + anchura / 2,x + anchura}, new int[]{y + altura, y, y + altura}, 3);
//        
//        g.setColor(new Color(0, 0, 255, 128));
//        g.fillPolygon(new int[]{x, x + anchura / 2,x + anchura}, new int[]{y + altura, y, y + altura}, 3);
    }
}